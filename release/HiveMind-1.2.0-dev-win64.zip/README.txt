HiveMind portable desktop build
================================
Version: 1.2.0-dev
Commit:  22be7cb0ccdc08c1619ce3133280956cf43d88de
Built:   2026-11-13T18:32:35.2108977-06:00

Run HiveMind.exe. It starts hiverouter.exe (beside this file) on the first free
loopback port in 8099..8199, waits for /health, then opens the UI in an Edge or
Chrome app window.

Data and the workspace live in:
  %LOCALAPPDATA%\HiveMind\provider.key      DPAPI-encrypted provider key
  %LOCALAPPDATA%\HiveMind\provider.json     non-secret provider profile
  %LOCALAPPDATA%\HiveMind\workspace         agent workspace (created on launch)

The launcher decrypts the provider key and injects it into the server child only.
Create or rotate it with the adjacent script:
  powershell -ExecutionPolicy Bypass -File set-provider-key.ps1
The key is never written into this folder, source, command lines, or logs.

Install for this user (shortcuts, first-run setup):
  powershell -ExecutionPolicy Bypass -File install-desktop.ps1

The adjacent agent-native CLI is hivemind.cmd (Node >= 22.12 required):
  hivemind.cmd status --json
  hivemind.cmd run --prompt "..." --json
  hivemind.cmd jobs --json
  hivemind.cmd --help

No Tauri, no Visual Studio, no MSVC Build Tools are required.
The UI is the same embedded web/dist served by the Rust binary.
